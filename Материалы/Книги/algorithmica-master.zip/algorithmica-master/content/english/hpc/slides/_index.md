---
title: Slides
ignoreIndexing: true
weight: 1000
draft: true
---

This is an attempt to make a university course out of the book.

Work in progress.
