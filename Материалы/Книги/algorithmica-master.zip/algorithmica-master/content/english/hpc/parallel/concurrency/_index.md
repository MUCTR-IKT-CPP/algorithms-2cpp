---
title: Concurrency
weight: 1
---

Concurrency is the ability of different parts of a program to execute out-of-order (or possibly in parallel), without affecting the result.

Concurrency is everywhere. You may listen to music while reading this book. Two programs manage, even if they work on the same core.

Multi-threaded programming. Much harder than normal one. Different langauges solve this problem differently. In this section we will go through the main approaches.
