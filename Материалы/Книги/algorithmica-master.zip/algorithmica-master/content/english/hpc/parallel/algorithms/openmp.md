---
title: OpenMP
---
