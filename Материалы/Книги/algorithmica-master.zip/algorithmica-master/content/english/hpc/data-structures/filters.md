---
title: Probabilistic Filters
weight: 10
draft: true
---

bloom filters have the inverse behavior of caches*
- bloom filter: miss == definitely not present, hit == probably present
- cache: miss == probably not present, hit == definitely present
