---
title: Random Number Generation
weight: 7
draft: true
---

We can use iterated hash function for what it's worth.

Linear congruent generator
period of LCG

