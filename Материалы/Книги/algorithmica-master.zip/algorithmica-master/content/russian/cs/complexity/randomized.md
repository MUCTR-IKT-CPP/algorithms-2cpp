---
title: Рандомизированные алгоритмы
weight: 5
draft: true
---

## BogoSort

## Стационарные точки

## Обновления минимума

```cpp
int m = 1e9, cnt = 0;
for (int i = 0; i < n; i++)
    if (a[i] < m)
        m = i, cnt++;
```

$O(\log n)$
