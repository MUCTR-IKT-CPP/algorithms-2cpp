---
title: Факторизация за корень
weight: 2
draft: true
---
