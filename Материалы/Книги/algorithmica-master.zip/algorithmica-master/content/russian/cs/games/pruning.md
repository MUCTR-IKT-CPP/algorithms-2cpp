---
title: Перебор с отсечениями
weight: 4
draft: true
---