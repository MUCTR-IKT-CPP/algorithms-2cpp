---
title: Softmax
---
