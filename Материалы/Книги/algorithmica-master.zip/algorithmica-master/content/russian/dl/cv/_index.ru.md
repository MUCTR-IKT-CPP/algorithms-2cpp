---
title: Компьютерное зрение
menuTitle: CV
weight: 4
---
