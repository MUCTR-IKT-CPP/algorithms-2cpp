---
title: Глубокое обучение
menuTitle: DL
weight: 4
draft: true
---
