---
title: Презентация про градиентный спуск
outputs:
- Reveal
---
