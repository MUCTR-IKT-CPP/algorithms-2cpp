---
title: Компьютерная лингвистика
menuTitle: NLP
weight: 5
---
