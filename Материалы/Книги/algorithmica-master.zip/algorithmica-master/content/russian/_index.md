---
title: Алгоритмика
hideSidebar: true
---

На этом сайте находятся материалы различных CS-курсов, проводящихся в [Tinkoff Generation](https://fintech.tinkoff.ru/study/generation/).

Проект открытый, живёт на [гитхабе](https://github.com/algorithmica-org/algorithmica). Помощь в [подготовке статей](contributing), исправление ошибок и любая другая обратная связь очень приветствуется. Разрабатывает и поддерживает [Сергей Слотин](http://sereja.me/).
